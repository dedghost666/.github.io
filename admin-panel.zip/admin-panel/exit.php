                            </div><!-- col-sm-6 -->
							</div><!-- row -->
							</div><!-- contentpanel -->
							</div><!-- mainpanel -->
							</section>


<?php
 include ('include/footer.php');
 ?>
 	
</body>
</html>